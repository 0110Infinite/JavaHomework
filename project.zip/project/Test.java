package project;

public class Test {
    public static void main(String[] args) {
        AdminView view = new View();
        view.menu();
    }
}
